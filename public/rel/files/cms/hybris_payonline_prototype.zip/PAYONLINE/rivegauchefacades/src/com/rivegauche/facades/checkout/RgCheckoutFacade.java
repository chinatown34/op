package com.rivegauche.facades.checkout;

import com.rivegauche.facades.order.data.OrderSummaryData;
import com.rivegauche.facades.payment.data.RgPaymentInfoData;
import com.teamidea.integration.prototype.exception.PayonlinePrototypeException;
import com.teamidea.integration.prototype.payonline.data.RequestData;
import de.hybris.platform.acceleratorfacades.order.AcceleratorCheckoutFacade;
import de.hybris.platform.commercefacades.order.data.DeliveryModeData;
import de.hybris.platform.order.InvalidCartException;

import java.util.List;

public interface RgCheckoutFacade extends AcceleratorCheckoutFacade {

    boolean setPaymentMode(String paymentModeCode);

    List<DeliveryModeData> getCartSupportedDeliveryMethods();

    boolean setRgPaymentInfo(RgPaymentInfoData rgPaymentInfoData);

    RequestData createRequestDataForOrder(OrderSummaryData order) throws PayonlinePrototypeException;

    OrderSummaryData placeRgOrders() throws InvalidCartException;

    boolean isSelectedPaymentModeMaxValueExceeded();

    void setOrderPayonlineTransactionId(String orderId, String transactionID);
}
