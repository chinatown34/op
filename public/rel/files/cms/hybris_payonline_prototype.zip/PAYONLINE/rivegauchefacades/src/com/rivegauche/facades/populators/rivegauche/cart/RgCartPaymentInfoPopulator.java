package com.rivegauche.facades.populators.rivegauche.cart;

import com.rivegauche.facades.payment.data.RgPayonlinePaymentInfoData;
import com.rivegauche.facades.payment.data.RgQiwiPaymentInfoData;
import com.rivegauche.model.RgPaymentInfoModel;
import com.rivegauche.model.RgPayonlinePaymentInfoModel;
import de.hybris.platform.commercefacades.order.data.CartData;
import de.hybris.platform.converters.Populator;
import de.hybris.platform.core.model.order.CartModel;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;
import de.hybris.platform.servicelayer.dto.converter.Converter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class RgCartPaymentInfoPopulator implements Populator<CartModel, CartData> {

    @Autowired
    private Converter<RgPayonlinePaymentInfoModel, RgPayonlinePaymentInfoData> rgPayonlinePaymentInfoConverter;

    @Override
    public void populate(CartModel cartModel, CartData cartData) throws ConversionException {
        RgPaymentInfoModel rgPaymentInfo = cartModel.getRgPaymentInfo();

        if (rgPaymentInfo != null) {
            if(RgPayonlinePaymentInfoModel._TYPECODE.equals(rgPaymentInfo.getItemtype())) {
                cartData.setRgPaymentInfo(rgPayonlinePaymentInfoConverter.convert((RgPayonlinePaymentInfoModel)rgPaymentInfo));
            }
        }
    }

}
