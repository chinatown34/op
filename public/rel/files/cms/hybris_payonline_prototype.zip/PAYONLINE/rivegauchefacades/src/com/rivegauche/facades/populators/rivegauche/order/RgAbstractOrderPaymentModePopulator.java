package com.rivegauche.facades.populators.rivegauche.order;

import com.rivegauche.facades.payment.data.RgPaymentModeData;
import de.hybris.platform.commercefacades.order.data.AbstractOrderData;
import de.hybris.platform.converters.Populator;
import de.hybris.platform.core.model.order.AbstractOrderModel;
import de.hybris.platform.core.model.order.payment.PaymentModeModel;
import de.hybris.platform.paymentstandard.model.StandardPaymentModeModel;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;
import de.hybris.platform.servicelayer.dto.converter.Converter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class RgAbstractOrderPaymentModePopulator implements Populator<AbstractOrderModel, AbstractOrderData> {

    @Autowired
    private Converter<StandardPaymentModeModel, RgPaymentModeData> rgPaymentModeConverter;

    @Override
    public void populate(AbstractOrderModel abstractOrderModel, AbstractOrderData abstractOrderData) throws ConversionException {
        PaymentModeModel paymentModeModel = abstractOrderModel.getPaymentMode();
        if (paymentModeModel != null && StandardPaymentModeModel._TYPECODE.equals(paymentModeModel.getItemtype()))  {
            abstractOrderData.setRgPaymentMode(rgPaymentModeConverter.convert((StandardPaymentModeModel)paymentModeModel));
        }
    }
}
