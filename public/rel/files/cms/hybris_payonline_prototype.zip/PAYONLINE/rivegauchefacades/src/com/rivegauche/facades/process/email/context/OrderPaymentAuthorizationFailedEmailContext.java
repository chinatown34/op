package com.rivegauche.facades.process.email.context;

import de.hybris.platform.acceleratorservices.model.cms2.pages.EmailPageModel;
import de.hybris.platform.orderprocessing.model.OrderProcessModel;

public class OrderPaymentAuthorizationFailedEmailContext extends OrderEmailContext {

    @Override
    public void init(final OrderProcessModel orderProcessModel, final EmailPageModel emailPageModel)
    {
        super.init(orderProcessModel, emailPageModel);
    }
}