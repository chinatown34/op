package com.rivegauche.facades.populators.rivegauche.payment;

import com.rivegauche.facades.payment.data.RgPayonlinePaymentInfoData;
import com.rivegauche.model.RgPayonlinePaymentInfoModel;
import de.hybris.platform.converters.Populator;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;
import org.springframework.stereotype.Component;

@Component
public class RgPayonlinePaymentInfoPopulator implements Populator<RgPayonlinePaymentInfoModel, RgPayonlinePaymentInfoData> {

    @Override
    public void populate(RgPayonlinePaymentInfoModel rgPayonlinePaymentInfoModel, RgPayonlinePaymentInfoData rgPayonlinePaymentInfoData) throws ConversionException {
        rgPayonlinePaymentInfoData.setTransactionId(rgPayonlinePaymentInfoModel.getTransactionId());
    }
}
