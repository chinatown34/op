package com.rivegauche.facades.checkout.impl;

import com.rivegauche.constants.RivegauchestoreConstants;
import com.rivegauche.facades.checkout.RgCheckoutFacade;
import com.rivegauche.facades.order.data.OrderSummaryData;
import com.rivegauche.facades.payment.data.RgPaymentInfoData;
import com.rivegauche.facades.payment.data.RgPaymentModeData;
import com.rivegauche.facades.payment.data.RgPayonlinePaymentInfoData;
import com.rivegauche.facades.util.RgDeliveryModeUtil;
import com.rivegauche.model.RgPaymentInfoModel;
import com.rivegauche.model.RgPayonlinePaymentInfoModel;
import com.rivegauche.promotions.model.RgOrderThresholdChangeDeliveryModePromotionModel;
import com.rivegauche.services.RgCartService;
import com.rivegauche.services.RgCheckoutService;
import com.rivegauche.services.RgDeliveryService;
import com.rivegauche.services.RgPaymentInfoService;
import com.rivegauche.services.RgCustomerAccountService;
import com.teamidea.integration.prototype.exception.PayonlinePrototypeException;
import com.teamidea.integration.prototype.payonline.client.PayonlineClient;
import com.teamidea.integration.prototype.payonline.data.RequestData;
import de.hybris.platform.acceleratorfacades.order.impl.DefaultAcceleratorCheckoutFacade;
import de.hybris.platform.commercefacades.order.data.CartData;
import de.hybris.platform.commercefacades.order.data.DeliveryModeData;
import de.hybris.platform.commercefacades.order.data.OrderData;
import de.hybris.platform.commerceservices.enums.CustomerType;
import de.hybris.platform.core.model.order.CartModel;
import de.hybris.platform.core.model.order.OrderModel;
import de.hybris.platform.core.model.order.delivery.DeliveryModeModel;
import de.hybris.platform.core.model.order.payment.PaymentModeModel;
import de.hybris.platform.core.model.user.CustomerModel;
import de.hybris.platform.core.model.user.UserModel;
import de.hybris.platform.order.InvalidCartException;
import de.hybris.platform.order.PaymentModeService;
import de.hybris.platform.promotions.model.OrderThresholdChangeDeliveryModePromotionModel;
import de.hybris.platform.promotions.model.PromotionResultModel;
import de.hybris.platform.servicelayer.dto.converter.Converter;
import de.hybris.platform.voucher.VoucherService;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;

public class RgCheckoutFacadeImpl extends DefaultAcceleratorCheckoutFacade implements RgCheckoutFacade {
    private static final Logger LOG = Logger.getLogger(RgCheckoutFacadeImpl.class);

    @Autowired
    private PaymentModeService paymentModeService;

    @Autowired
    RgCheckoutService rgCheckoutService;

    @Autowired
    @Qualifier("rgPayonlinePaymentInfoConverter")
    private Converter<RgPayonlinePaymentInfoModel, RgPayonlinePaymentInfoData> rgPayonlinePaymentInfoConverter;

    @Autowired
    private Converter<DeliveryModeModel, DeliveryModeData> deliveryModeConverter;

    @Autowired
    private RgCartService cartService;

    @Autowired
    private RgPaymentInfoService rgPaymentInfoService;

    @Autowired
    private Converter<CartModel, CartData> cartConverter;

    @Autowired
    private VoucherService voucherService;

    @Autowired
    private RgDeliveryService rgDeliveryService;

    @Autowired
    private RgDeliveryModeUtil rgDeliveryModeUtil;

    @Resource(name="customerAccountService")
    private RgCustomerAccountService customerAccountService;

    @PostConstruct
    public void postConstruct() throws PayonlinePrototypeException {
        payonlineClient = new PayonlineClient();
    }

    @Override
    public boolean setPaymentMode(String paymentModeCode) {
        boolean result = false;

        if (StringUtils.isNotEmpty(paymentModeCode)) {
            CartModel cartModel = getCart();
            if (cartModel != null) {
                PaymentModeModel paymentModeModel = paymentModeService.getPaymentModeForCode(paymentModeCode);
                result = rgCheckoutService.setPaymentMode(cartModel, paymentModeModel);
            }
        }
        return result;
    }

    @Override
    public List<DeliveryModeData> getCartSupportedDeliveryMethods() {
        List<DeliveryModeData> deliveryMethods =  new ArrayList<DeliveryModeData>();
        final CartModel cartModel = getCart();
        if (cartModel != null)
        {
            DeliveryModeModel cartDeliveryMode = cartModel.getDeliveryMode();
            if (cartModel.getDeliveryMode() != null && cartHasPromotionDelivery(cartModel))
            {
                deliveryMethods.add(getRgDeliveryService().restrictDeliveryModeData(cartDeliveryMode));
            } else {
                deliveryMethods.addAll(getSupportedDeliveryModes());
            }
        }
        return deliveryMethods;
    }

    private boolean cartHasPromotionDelivery(CartModel cartModel) {
        Set<PromotionResultModel> appliedPromotions = cartModel.getAllPromotionResults();
        if(CollectionUtils.isNotEmpty(appliedPromotions)){
            for(PromotionResultModel promotionResultModel : appliedPromotions) {
                if(isOrderThresholdChangeDeliveryModePromotion(promotionResultModel)) {
                    String cartDeliveryCode = cartModel.getDeliveryMode().getCode();
                    String promotionDeliveryCode = ((OrderThresholdChangeDeliveryModePromotionModel)promotionResultModel.getPromotion()).getDeliveryMode().getCode();
                    return promotionDeliveryCode.equals(cartDeliveryCode);
                }
            }
        }
        return false;
    }

    //TODO replace check with a flag on PointOfService
    private boolean isOrderThresholdChangeDeliveryModePromotion(PromotionResultModel promotionResultModel) {
        return OrderThresholdChangeDeliveryModePromotionModel._TYPECODE.equals(promotionResultModel.getPromotion().getItemtype())
                || RgOrderThresholdChangeDeliveryModePromotionModel._TYPECODE.equals(promotionResultModel.getPromotion().getItemtype());
    }

    @Override
    public boolean setRgPaymentInfo(RgPaymentInfoData rgPaymentInfoData) {
        CartModel cartModel = getCart();
        
        if (cartModel != null) {
            if (rgPaymentInfoData instanceof RgPayonlinePaymentInfoData) {
                rgPaymentInfoService.setRgPayonlinePaymentInfo((RgPayonlinePaymentInfoData) rgPaymentInfoData, cartModel);

                return true;
            }
        }
        
        return false;
    }

    @Override
    public CartData getCheckoutCart() {
        CartData cartData = getCartFacade().getSessionCart();
        if (cartData != null) {
            cartData.setDeliveryAddress(getDeliveryAddress());
            cartData.setDeliveryMode(getDeliveryMode());
            cartData.setPaymentInfo(getPaymentDetails());

            cartData.setRgPaymentInfo(getRgPaymentInfo());
        }

        return cartData;
    }

    @Override
    public RequestData createRequestDataForOrder(OrderSummaryData orderSummary) throws PayonlinePrototypeException {

        OrderData deliveryOrder = orderSummary.getDeliveryOrder();
        OrderData pickupOrder = orderSummary.getPickupOrder();

        String deliveryOrderId = deliveryOrder.getCode();
        String deliveryOrderGuid = deliveryOrder.getGuid();

        String pickupOrderId = null;
        String pickupOrderGuid = null;
        if(pickupOrder != null) {
            pickupOrderId = pickupOrder.getCode();
            pickupOrderGuid = pickupOrder.getGuid();
        }
        BigDecimal amount = deliveryOrder.getTotalPriceWithTax().getValue();

        return payonlineClient.createRequestDataForOrder(deliveryOrderId, deliveryOrderGuid, pickupOrderId, pickupOrderGuid, amount);
    }

    protected RgPaymentInfoData getRgPaymentInfo() {
        CartModel cartModel = getCart();

        if (cartModel != null) {
            RgPaymentInfoModel rgPaymentInfoModel = cartModel.getRgPaymentInfo();

            if (rgPaymentInfoModel instanceof RgPayonlinePaymentInfoModel) {
                RgPayonlinePaymentInfoModel rgPayonlinePaymentInfoModel =
                        (RgPayonlinePaymentInfoModel) rgPaymentInfoModel;
                RgPayonlinePaymentInfoData rgPayonlinePaymentInfoData =
                        rgPayonlinePaymentInfoConverter.convert(rgPayonlinePaymentInfoModel);

                return rgPayonlinePaymentInfoData;
            }
        }

        return null;
    }

    @Override
    public OrderSummaryData placeRgOrders() throws InvalidCartException {
        final CartModel cartModel = getCart();

        if (cartModel != null)
        {
            final UserModel currentUser = getCurrentUserForCheckout();
            if (cartModel.getUser().equals(currentUser) || getCheckoutCustomerStrategy().isAnonymousCheckout())
            {
                return doPlaceOrder(cartModel);
            }
        }

        return null;
    }

    /**
     * if cartModel has only shipping items place single order
     * else split order
     *
     * @param cartModel
     * @return
     * @throws InvalidCartException
     */
    private OrderSummaryData doPlaceOrder(CartModel cartModel) throws InvalidCartException {
        OrderSummaryData orderSummaryData = null;
        beforePlaceOrder(cartModel);

        if(hasShippingItems() && hasPickUpItems()) {
            //split order for delivery and pickup
            final CartModel newDeliveryCartModel = getCartService().getCartForDelivery(cartModel);
            final CartModel newPickupCartModel = getCartService().getCartForPickup(cartModel);

            try {
                orderSummaryData = placeOrders(cartModel, newDeliveryCartModel, newPickupCartModel);
            } catch (Exception e) {
                throw e;
            } finally {
                getModelService().remove(newDeliveryCartModel);
                getModelService().remove(newPickupCartModel);
            }
        } else {
            // place one order
            final OrderModel orderModel = placeOrder(cartModel);
            boolean onlyPickup = hasPickUpItems();
            afterPlaceOrder(cartModel, orderModel);
            orderSummaryData = getOrderSummaryData(orderModel, onlyPickup);
        }

        return orderSummaryData;
    }

    private OrderSummaryData placeOrders(CartModel sessionCart, CartModel deliveryCartModel, CartModel pickupCartModel) throws InvalidCartException {
        createGuestCustomerEmail(sessionCart);
        OrderModel orderModelForDelivery = placeOrder(deliveryCartModel);
        OrderModel orderModelForPickup = placeOrder(pickupCartModel);

        afterPlaceOrders(sessionCart, orderModelForDelivery, orderModelForPickup);

        OrderSummaryData orderSummaryData = new OrderSummaryData();
        orderSummaryData.setDeliveryOrder(getOrderConverter().convert(orderModelForDelivery));
        orderSummaryData.setPickupOrder(getOrderConverter().convert(orderModelForPickup));

        return orderSummaryData;
    }

    private void createGuestCustomerEmail(CartModel sessionCart) {
        CustomerModel customerModel = (CustomerModel) sessionCart.getUser();
        if(CustomerType.GUEST.equals(customerModel.getType())) {
            LOG.info("Create guest customer email if not exists. Customer code " + customerModel.getUid());
            getCustomerAccountService().createCustomerEmailAddressIfNotExists(customerModel);
        }
    }

    protected void afterPlaceOrders(final CartModel sessionCart, final OrderModel deliveryOrder, final OrderModel pickupOrder)
    {
        if (deliveryOrder != null && pickupOrder != null)
        {
            createVoucherInvalidation(sessionCart, deliveryOrder);

            // Remove cart
            getCartService().removeSessionCart();
            getModelService().refresh(deliveryOrder);
            getModelService().refresh(pickupOrder);
            //clean previous card because it can be restored after next login
            getCartFacade().cleanSavedCart();
        }
    }

    private OrderSummaryData getOrderSummaryData(OrderModel orderModel, boolean forPickup) {
        OrderSummaryData orderSummaryData = new OrderSummaryData();
        if(forPickup) {
            orderSummaryData.setPickupOrder(getOrderConverter().convert(orderModel));
        } else {
            orderSummaryData.setDeliveryOrder(getOrderConverter().convert(orderModel));
        }
        return orderSummaryData;
    }

    @Override
    protected void afterPlaceOrder(final CartModel cartModel, final OrderModel orderModel) {
        if (orderModel!= null && cartModel != null) {
            createVoucherInvalidation(cartModel, orderModel);
        }
        super.afterPlaceOrder(cartModel, orderModel);
    }

    private void createVoucherInvalidation(CartModel sessionCart, OrderModel orderModel) {
        Collection<String> appliedVoucherCodes = getVoucherService().getAppliedVoucherCodes(sessionCart);
        if (appliedVoucherCodes != null) {
            for (String voucherCode : appliedVoucherCodes) {
                getVoucherService().createVoucherInvalidation(voucherCode, orderModel);
            }
        }
    }

    @Override
    public List<? extends DeliveryModeData> getSupportedDeliveryModes()
    {
        final List<DeliveryModeData> result = new ArrayList<DeliveryModeData>();
        final CartModel cartModel = getCart();
        if (cartModel != null)
        {
            final Collection<DeliveryModeModel> supportedDeliveryModes = getDeliveryService().getSupportedDeliveryModeListForOrder(
                    cartModel);

            for (final DeliveryModeModel deliveryModeModel : supportedDeliveryModes)
            {
                DeliveryModeData deliveryModeData = getRgDeliveryService().restrictDeliveryModeData(deliveryModeModel);
                rgDeliveryModeUtil.setDeliveryCost(deliveryModeData, deliveryModeModel, cartModel);

                result.add(deliveryModeData);
            }
        }

        return result;
    }

    @Override
    public boolean isSelectedPaymentModeMaxValueExceeded() {
        boolean result = false;
        if(hasShippingItems()) {
            RgPaymentModeData paymentModeData = getCheckoutCart().getRgPaymentMode();
            if(paymentModeData.getPaymentModeMaxValue() != null
                    && cartService.getDeliveryItemsTotalPrice().compareTo(paymentModeData.getPaymentModeMaxValue().getValue()) > 0) {
                result = true;
            }
        }
        return result;
    }

    @Override
    public void setOrderPayonlineTransactionId(String orderId, String transactionID) {
        rgPaymentInfoService.setOrderPayonlineTransactionId(orderId, transactionID);
    }

    public VoucherService getVoucherService() {
        return voucherService;
    }

    public RgCartService getCartService() {
        return cartService;
    }

    public void setCartService(RgCartService cartService) {
        this.cartService = cartService;
    }

    public RgDeliveryService getRgDeliveryService() {
        return rgDeliveryService;
    }

    public RgCustomerAccountService getCustomerAccountService() {
        return customerAccountService;
    }

    public void setCustomerAccountService(RgCustomerAccountService customerAccountService) {
        this.customerAccountService = customerAccountService;
    }
}
