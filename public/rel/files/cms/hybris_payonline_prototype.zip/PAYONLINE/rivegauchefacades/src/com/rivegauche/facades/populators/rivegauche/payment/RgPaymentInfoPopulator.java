package com.rivegauche.facades.populators.rivegauche.payment;

import com.rivegauche.facades.payment.data.RgPaymentInfoData;
import com.rivegauche.model.RgPaymentInfoModel;
import de.hybris.platform.converters.Populator;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;
import org.springframework.stereotype.Component;

@Component
public class RgPaymentInfoPopulator implements Populator<RgPaymentInfoModel, RgPaymentInfoData> {

    @Override
    public void populate(RgPaymentInfoModel rgPaymentInfoModel, RgPaymentInfoData rgPaymentInfoData) throws ConversionException {
        rgPaymentInfoData.setCode(rgPaymentInfoModel.getCode());
    }
}
