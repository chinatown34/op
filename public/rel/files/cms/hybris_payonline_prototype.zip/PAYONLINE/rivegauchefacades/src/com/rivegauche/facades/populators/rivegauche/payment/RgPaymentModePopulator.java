package com.rivegauche.facades.populators.rivegauche.payment;

import com.rivegauche.facades.payment.data.RgPaymentModeData;
import com.rivegauche.model.RgPaymentModeMaxValueModel;
import com.rivegauche.services.RgCartService;
import de.hybris.platform.commercefacades.product.PriceDataFactory;
import de.hybris.platform.commercefacades.product.data.PriceData;
import de.hybris.platform.commercefacades.product.data.PriceDataType;
import de.hybris.platform.converters.Populator;
import de.hybris.platform.core.model.c2l.CurrencyModel;
import de.hybris.platform.core.model.order.CartModel;
import de.hybris.platform.core.model.order.payment.PaymentModeModel;
import de.hybris.platform.paymentstandard.model.StandardPaymentModeModel;
import de.hybris.platform.paymentstandard.model.StandardPaymentModeValueModel;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;
import de.hybris.platform.servicelayer.i18n.CommonI18NService;
import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import java.math.BigDecimal;
import java.util.Collection;
@Component
public class RgPaymentModePopulator implements Populator<PaymentModeModel, RgPaymentModeData> {

    private static final Logger LOG = Logger.getLogger(RgPaymentModePopulator.class);

    @Autowired
    private PriceDataFactory priceDataFactory;

    @Autowired
    private CommonI18NService commonI18NService;

    @Autowired
    private RgCartService cartService;

    @Override
    public void populate(PaymentModeModel paymentModeModel, RgPaymentModeData rgPaymentModeData) throws ConversionException {
        Assert.notNull(paymentModeModel, "Parameter source cannot be null.");
        Assert.notNull(rgPaymentModeData, "Parameter target cannot be null.");

        rgPaymentModeData.setCode(paymentModeModel.getCode());
        rgPaymentModeData.setName(paymentModeModel.getName());
        rgPaymentModeData.setDescription(paymentModeModel.getDescription());

        if(StandardPaymentModeModel._TYPECODE.equals(paymentModeModel.getItemtype())) {
            populateTransactionCost((StandardPaymentModeModel) paymentModeModel, rgPaymentModeData);
            populatePaymentModeMaxValue((StandardPaymentModeModel) paymentModeModel, rgPaymentModeData);
        }
    }

    private void populatePaymentModeMaxValue(StandardPaymentModeModel paymentModeModel, RgPaymentModeData rgPaymentModeData) {
        if(CollectionUtils.isNotEmpty(paymentModeModel.getRgPaymentModeMaxValues())) {
            CurrencyModel currentCurrency = commonI18NService.getCurrentCurrency();
            Double maxValue =  getPaymentModeMaxValue(((StandardPaymentModeModel) paymentModeModel).getRgPaymentModeMaxValues(), currentCurrency);
            PriceData maxValueData = priceDataFactory.create(PriceDataType.BUY, BigDecimal.valueOf(maxValue), currentCurrency.getIsocode());
            rgPaymentModeData.setPaymentModeMaxValue(maxValueData);
            rgPaymentModeData.setSelectable(cartService.getDeliveryItemsTotalPrice().compareTo(maxValueData.getValue()) <= 0);
        }
    }

    private Double getPaymentModeMaxValue(Collection<RgPaymentModeMaxValueModel> standardPaymentModeValues, CurrencyModel currency) {
        Double maxValue = 0d;
        for(RgPaymentModeMaxValueModel maxPaymentModeValue : standardPaymentModeValues) {
            if (maxPaymentModeValue.getCurrency().equals(currency)) {
                maxValue = maxPaymentModeValue.getValue();
                break;
            }
        }
        return maxValue;
    }

    private void populateTransactionCost(StandardPaymentModeModel paymentModeModel, RgPaymentModeData rgPaymentModeData) {
        CurrencyModel currentCurrency = commonI18NService.getCurrentCurrency();
        Double transactionCost = getTransactionCost(paymentModeModel.getPaymentModeValues(), currentCurrency);
        PriceData priceData = priceDataFactory.create(PriceDataType.BUY, BigDecimal.valueOf(transactionCost), currentCurrency.getIsocode());

        rgPaymentModeData.setTransactionCost(priceData);
    }


    private Double getTransactionCost(Collection<StandardPaymentModeValueModel> standardPaymentModeValues, CurrencyModel currency) {
        Double transactionCost = 0d;
        for(StandardPaymentModeValueModel standardPaymentModeValue : standardPaymentModeValues) {
           if (standardPaymentModeValue.getCurrency().equals(currency)) {
               transactionCost = standardPaymentModeValue.getValue();
               break;
           }
        }
        return transactionCost;
    }
}
