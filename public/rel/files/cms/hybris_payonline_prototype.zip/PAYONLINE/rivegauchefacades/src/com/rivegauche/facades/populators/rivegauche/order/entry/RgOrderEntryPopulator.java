package com.rivegauche.facades.populators.rivegauche.order.entry;

import de.hybris.platform.commercefacades.order.data.OrderEntryData;
import de.hybris.platform.converters.Populator;
import de.hybris.platform.core.model.order.AbstractOrderEntryModel;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;
import org.springframework.stereotype.Component;


@Component
public class RgOrderEntryPopulator implements Populator<AbstractOrderEntryModel, OrderEntryData> {

    @Override
    public void populate(AbstractOrderEntryModel abstractOrderEntryModel, OrderEntryData orderEntryData) throws ConversionException {
        if (abstractOrderEntryModel.getGiveAway() != null) {
            orderEntryData.setGiveAway(abstractOrderEntryModel.getGiveAway());
        }
    }
}
