package com.rivegauche.services;

import com.rivegauche.facades.payment.data.RgPayonlinePaymentInfoData;
import de.hybris.platform.core.model.order.CartModel;

public interface RgPaymentInfoService {
    void setRgPayonlinePaymentInfo(RgPayonlinePaymentInfoData rgPayonlinePaymentInfoData, CartModel cartModel);
}
