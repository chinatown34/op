package com.rivegauche.services.impl;

import com.rivegauche.daos.RgPayonlinePaymentInfoDao;
import com.rivegauche.model.RgPayonlinePaymentInfoModel;
import com.rivegauche.services.RgPayonlinePaymentInfoService;
import de.hybris.platform.servicelayer.exceptions.AmbiguousIdentifierException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("rgPayonlinePaymentInfoService")
public class RgPayonlinePaymentInfoServiceImpl implements RgPayonlinePaymentInfoService {

    @Autowired
    private RgPayonlinePaymentInfoDao rgPayonlinePaymentInfoDao;

    @Override
    public RgPayonlinePaymentInfoModel getRgPayonlinePaymentInfoForCode(String code) {
        List<RgPayonlinePaymentInfoModel> result = rgPayonlinePaymentInfoDao.findRgPaymentInfoByCode(code);

        if (result.isEmpty()) {
            return null;
        } else if (result.size() > 1) {
            throw new AmbiguousIdentifierException("RgPayonlinePaymentInfo code '" + code + "' is not unique, " + result.size()
                    + " RgPayonlinePaymentInfos found!");
        }

        return result.get(0);
    }

}
