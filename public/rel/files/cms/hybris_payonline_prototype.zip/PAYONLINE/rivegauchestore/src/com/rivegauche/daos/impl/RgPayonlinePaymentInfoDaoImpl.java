package com.rivegauche.daos.impl;

import com.rivegauche.daos.RgPayonlinePaymentInfoDao;
import com.rivegauche.model.RgPayonlinePaymentInfoModel;
import de.hybris.platform.servicelayer.search.FlexibleSearchQuery;
import de.hybris.platform.servicelayer.search.FlexibleSearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component("rgPayonlinePaymentInfoDao")
public class RgPayonlinePaymentInfoDaoImpl implements RgPayonlinePaymentInfoDao {

    @Autowired
    private FlexibleSearchService flexibleSearchService;

    @Override
    public List<RgPayonlinePaymentInfoModel> findRgPaymentInfoByCode(String code) {
        final String queryString = //
                "SELECT {p:" + RgPayonlinePaymentInfoModel.PK + "}" //
                        + "FROM {" + RgPayonlinePaymentInfoModel._TYPECODE + " AS p} "//
                        + "WHERE " + "{p:" + RgPayonlinePaymentInfoModel.CODE + "}=?code ";

        final FlexibleSearchQuery query = new FlexibleSearchQuery(queryString);
        query.addQueryParameter("code", code);

        return flexibleSearchService.<RgPayonlinePaymentInfoModel> search(query).getResult();
    }
}
