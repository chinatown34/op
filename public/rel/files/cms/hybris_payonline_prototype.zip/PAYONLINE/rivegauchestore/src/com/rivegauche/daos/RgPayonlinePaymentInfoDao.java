package com.rivegauche.daos;

import com.rivegauche.model.RgPayonlinePaymentInfoModel;

import java.util.List;

public interface RgPayonlinePaymentInfoDao {

    public List<RgPayonlinePaymentInfoModel> findRgPaymentInfoByCode(String code);
}
