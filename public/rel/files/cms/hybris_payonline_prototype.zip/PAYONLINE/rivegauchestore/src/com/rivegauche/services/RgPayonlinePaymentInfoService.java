package com.rivegauche.services;

import com.rivegauche.model.RgPayonlinePaymentInfoModel;

public interface RgPayonlinePaymentInfoService {

    public RgPayonlinePaymentInfoModel getRgPayonlinePaymentInfoForCode(String code);

}
