/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2013 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 * 
 *  
 */
package com.rivegauche.constants;

import de.hybris.platform.util.Config;

/**
 * Global class for all Rivegauchestore constants. You can add global constants for your extension into this class.
 */
public final class RivegauchestoreConstants extends GeneratedRivegauchestoreConstants
{
	public static final String EXTENSIONNAME = "rivegauchestore";


	private RivegauchestoreConstants()
	{
		//empty to avoid instantiating this constant class
	}

    public static final String PAYONLINE_PAYMENT_PROVIDER_CODE = Config.getParameter("payonline.payment.provider.code");
    public static final String PAYONLINE_CHECKOUT_FORM_URL = Config.getParameter("payonline.checkout.form.url");

  }
