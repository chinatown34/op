package com.rivegauche.services.impl;

import com.rivegauche.facades.payment.data.RgPayonlinePaymentInfoData;
import com.rivegauche.model.RgPaymentInfoModel;
import com.rivegauche.model.RgPayonlinePaymentInfoModel;
import com.rivegauche.services.RgOrderService;
import com.rivegauche.services.RgPaymentInfoService;
import com.rivegauche.services.RgPayonlinePaymentInfoService;
import de.hybris.platform.core.model.order.CartModel;
import de.hybris.platform.core.model.order.OrderModel;
import de.hybris.platform.servicelayer.exceptions.UnknownIdentifierException;
import de.hybris.platform.servicelayer.model.ModelService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service("rgPaymentInfoService")
public class RgPaymentInfoServiceImpl implements RgPaymentInfoService {

    private static final Logger LOG = Logger.getLogger(RgPaymentInfoServiceImpl.class);

    @Autowired
    private ModelService modelService;

    @Autowired
    RgPayonlinePaymentInfoService rgPayonlinePaymentInfoService;

    @Resource(name="orderService")
    private RgOrderService rgOrderService;

    @Override
    public void setRgPayonlinePaymentInfo(RgPayonlinePaymentInfoData rgPayonlinePaymentInfoData, CartModel cartModel) {
        RgPayonlinePaymentInfoModel rgPayonlinePaymentInfoModel =
                rgPayonlinePaymentInfoService.getRgPayonlinePaymentInfoForCode(cartModel.getCode());

        if (rgPayonlinePaymentInfoModel == null) {
            rgPayonlinePaymentInfoModel = createRgPayonlinePaymentInfoModel(rgPayonlinePaymentInfoData);
        }

        populateRgPayonlinePaymentInfoModel(rgPayonlinePaymentInfoModel, rgPayonlinePaymentInfoData);

        storeRgPaymentInfoOnCart(rgPayonlinePaymentInfoModel, cartModel);
    }

    protected RgPayonlinePaymentInfoModel createRgPayonlinePaymentInfoModel(RgPayonlinePaymentInfoData rgPayonlinePaymentInfoData) {
        return getModelService().create(RgPayonlinePaymentInfoModel.class);
    }

    private void populateRgPayonlinePaymentInfoModel(RgPayonlinePaymentInfoModel rgPayonlinePaymentInfoModel,
                                                     RgPayonlinePaymentInfoData rgPayonlinePaymentInfoData) {
        rgPayonlinePaymentInfoModel.setCode(rgPayonlinePaymentInfoData.getCode());

        rgPayonlinePaymentInfoModel.setTransactionId(rgPayonlinePaymentInfoData.getTransactionId());

        modelService.save(rgPayonlinePaymentInfoModel);
        modelService.refresh(rgPayonlinePaymentInfoModel);
    }

    private void storeRgPaymentInfoOnCart(RgPaymentInfoModel rgPaymentInfoModel, CartModel cartModel) {
        cartModel.setRgPaymentInfo(rgPaymentInfoModel);

        getModelService().save(cartModel);
        getModelService().refresh(cartModel);
    }

    @Override
    public void setOrderPayonlineTransactionId(String orderId, String transactionID) {
        try {
            OrderModel orderModel = getRgOrderService().getOrderForCode(orderId);
            RgPaymentInfoModel orderPaymentInfo = orderModel.getRgPaymentInfo();
            if(RgPayonlinePaymentInfoModel._TYPECODE.equals(orderPaymentInfo.getItemtype())) {
                RgPayonlinePaymentInfoModel payonlinePaymentInfoModel = (RgPayonlinePaymentInfoModel) orderPaymentInfo;
                payonlinePaymentInfoModel.setTransactionId(transactionID);
                getModelService().save(payonlinePaymentInfoModel);
                getModelService().refresh(payonlinePaymentInfoModel);
            } else {
                LOG.error("Error while setting transaction id = " + transactionID + " for oder code = " + orderId
                        + ". Found orderPaymentInfo of type = " + orderPaymentInfo.getItemtype() + " while expecting type = " + RgPayonlinePaymentInfoModel._TYPECODE );
            }
        } catch (UnknownIdentifierException une ) {
            LOG.error("Order NOT FOUND while setting transaction id = " + transactionID + " for oder code = " + orderId);
        } catch (Exception e) {
            LOG.error("Error while setting transaction id = " + transactionID + " for oder code = " + orderId, e);
        }
    }

    public ModelService getModelService() {
        return modelService;
    }

    public RgOrderService getRgOrderService() {
        return rgOrderService;
    }

    public void setRgOrderService(RgOrderService rgOrderService) {
        this.rgOrderService = rgOrderService;
    }
}
