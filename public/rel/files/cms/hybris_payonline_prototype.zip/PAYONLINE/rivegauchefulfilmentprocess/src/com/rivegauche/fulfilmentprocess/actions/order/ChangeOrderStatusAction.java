package com.rivegauche.fulfilmentprocess.actions.order;

import com.rivegauche.enums.OrderType;
import de.hybris.platform.core.enums.OrderStatus;
import de.hybris.platform.core.enums.PaymentStatus;
import de.hybris.platform.core.model.order.OrderModel;
import de.hybris.platform.orderprocessing.model.OrderProcessModel;
import de.hybris.platform.processengine.action.AbstractProceduralAction;
import de.hybris.platform.task.RetryLaterException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ChangeOrderStatusAction extends AbstractProceduralAction<OrderProcessModel> {

    private final static Logger LOG = LoggerFactory.getLogger(ChangeOrderStatusAction.class);

    @Override
    public void executeAction(OrderProcessModel orderProcessModel) throws RetryLaterException, Exception {
        OrderModel order = orderProcessModel.getOrder();
        OrderStatus initialStatus = order.getStatus();
        if(isOrderForPickUp(order)) {
            setOrderStatus(order, OrderStatus.NEW);
        } else if(PaymentStatus.NOTPAID.equals(order.getPaymentStatus())) {
            setOrderStatus(order, OrderStatus.WAITING_FOR_PAYMENT);
        }

        if (LOG.isDebugEnabled()) {
            LOG.debug("Order status of the order :'" + order.getCode() + "' has changed from : '" + initialStatus + " to : '" + order.getStatus() + "'");
        }
    }

    public boolean isOrderForPickUp(OrderModel order) {
        return OrderType.PICKUP.equals(order.getOrderType());
    }
}
