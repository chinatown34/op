/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2013 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 * 
 *  
 */
package com.rivegauche.fulfilmentprocess.impl;

import com.rivegauche.enums.OrderType;
import com.rivegauche.fulfilmentprocess.CheckOrderService;
import de.hybris.platform.core.model.order.OrderModel;
import org.apache.log4j.Logger;


public class DefaultCheckOrderService implements CheckOrderService
{
    private static final Logger LOG = Logger.getLogger(DefaultCheckOrderService.class);

	@Override
	public boolean check(final OrderModel order)
	{
        boolean result = true;

		if (!order.getCalculated().booleanValue() || order.getEntries().isEmpty()) {
			// Order must be calculated and must have some lines
            result = false;
		} else if (OrderType.DELIVERY.equals(order.getOrderType())) {
            // Check order for delivery
            result = checkOrderForDelivery(order);
        } else if (OrderType.PICKUP.equals(order.getOrderType())) {
            // Check order for pickup
            result = checkOrderForPickup(order);
        } else {
            // Cart splitting went wrong
            LOG.error("Cart splitting went wrong. Found order '" + order.getCode() + "' with order type '" + order.getOrderType() + "' !!!!!!!!!!!!!!!!!!!");
            result = false;
        }
        return result;
	}

    private boolean checkOrderForPickup(OrderModel order) {
        return true;
    }

    private boolean checkOrderForDelivery(OrderModel order) {
        boolean result = false;
        if(validOrderPaymentMethod(order) && validOrderDeliveryMethod(order) && validOrderDeliveryAddress(order)) {
            result = true;
        }
        return result;
    }

    private boolean validOrderPaymentMethod(OrderModel order) {
        return order.getPaymentMode() != null;
    }

    private boolean validOrderDeliveryMethod(OrderModel order) {
        return order.getDeliveryMode() != null;
    }

    private boolean validOrderDeliveryAddress(OrderModel order) {
        return order.getDeliveryAddress() != null;
    }

}
