/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2013 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 * 
 *  
 */
package com.rivegauche.fulfilmentprocess.actions.order;

import com.rivegauche.fulfilmentprocess.constants.RivegaucheFulfilmentProcessConstants;
import com.rivegauche.fulfilmentprocess.utils.RgOrderPaymentProviderHelper;
import de.hybris.platform.core.enums.OrderStatus;
import de.hybris.platform.core.enums.PaymentStatus;
import de.hybris.platform.core.model.order.OrderModel;
import de.hybris.platform.core.model.order.payment.CreditCardPaymentInfoModel;
import de.hybris.platform.orderprocessing.model.OrderProcessModel;
import de.hybris.platform.processengine.action.AbstractAction;
import de.hybris.platform.task.RetryLaterException;
import de.hybris.platform.util.Config;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashSet;
import java.util.Set;

/**
 * This action implements payment authorization using {@link CreditCardPaymentInfoModel}. Any other payment model could
 * be implemented here, or in a separate action, if the process flow differs.
 */
public class CheckAuthorizeOrderPaymentAction extends AbstractAction<OrderProcessModel> {

    private static final Logger LOG = Logger.getLogger(CheckAuthorizeOrderPaymentAction.class);

    @Autowired
    private RgOrderPaymentProviderHelper rgOrderPaymentProviderHelper;

    @Override
    public String execute(OrderProcessModel orderProcessModel) throws RetryLaterException, Exception {
        return executeAction(orderProcessModel).toString();
    }

    @Override
    public Set<String> getTransitions() {
        return Transition.getStringValues();
    }

    public Transition executeAction(final OrderProcessModel process) {
        Transition result = Transition.NOT_AUTHORIZED;
        final OrderModel order = process.getOrder();

        if (order != null && order.getPaymentMode() != null) {
            String paymentModeCode = order.getPaymentMode().getCode();
            if (Config.getParameter(RivegaucheFulfilmentProcessConstants.RG_CASHONDELIVERY_PAYMENT_MODE_CODE).equals(paymentModeCode)) {
                result = checkOrderPayOnDeliveryPaymentStatus(order);
            } else {
                result = checkOrderPaymentStatus(order);
            }
        }
        if (LOG.isDebugEnabled()) {
            LOG.debug("Payment authorization transition result :'" + result + "' for payment status : '" + order.getPaymentStatus() + "'");
        }
        return result;
    }

    protected Transition checkOrderPayOnDeliveryPaymentStatus(OrderModel order) {
        order.setStatus(OrderStatus.CHECKED_VALID);
        order.setPaymentStatus(PaymentStatus.PAID_ON_DELIVERY);
        modelService.save(order);
        return Transition.AUTHORIZED_PAID_ON_DELIVERY;
    }

    protected Transition checkOrderPaymentStatus(OrderModel order) {
        Transition transition = Transition.NOT_AUTHORIZED;
        PaymentStatus status = getRgOrderPaymentProviderHelper().getPaymentProviderOrderPaymentStatus(order);
        if (status != null) {
            order.setStatus(OrderStatus.PAYMENT_AUTHORIZED);
            order.setPaymentStatus(status);
            modelService.save(order);
            transition = getTransitionFromPaymentStatus(status);
        }
        return transition;
    }

    protected Transition getTransitionFromPaymentStatus(PaymentStatus paymentStatus) {
        Transition transition = Transition.NOT_AUTHORIZED;
        if (PaymentStatus.PAID.equals(paymentStatus)) {
            transition = Transition.AUTHORIZED_PAID;
        } else if (PaymentStatus.NOTPAID.equals(paymentStatus)) {
            transition = Transition.AUTHORIZED_NOT_PAID;
        } else if (PaymentStatus.PAID_ON_DELIVERY.equals(paymentStatus)) {
            transition = Transition.AUTHORIZED_PAID_ON_DELIVERY;
        }
        return transition;
    }

    protected enum Transition {
        AUTHORIZED_PAID, AUTHORIZED_NOT_PAID, AUTHORIZED_PAID_ON_DELIVERY, NOT_AUTHORIZED;

        public static Set<String> getStringValues() {
            final Set<String> res = new HashSet<String>();
            for (final Transition transitions : Transition.values()) {
                res.add(transitions.toString());
            }
            return res;
        }
    }

    public RgOrderPaymentProviderHelper getRgOrderPaymentProviderHelper() {
        return rgOrderPaymentProviderHelper;
    }

    public void setRgOrderPaymentProviderHelper(RgOrderPaymentProviderHelper rgOrderPaymentProviderHelper) {
        this.rgOrderPaymentProviderHelper = rgOrderPaymentProviderHelper;
    }
}
