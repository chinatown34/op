package com.rivegauche.fulfilmentprocess.jalo;

import com.rivegauche.fulfilmentprocess.constants.RivegaucheFulfilmentProcessConstants;
import de.hybris.platform.jalo.JaloSession;
import de.hybris.platform.jalo.extension.ExtensionManager;
import org.apache.log4j.Logger;

@SuppressWarnings("PMD")
public class RivegaucheFulfilmentProcessManager extends GeneratedRivegaucheFulfilmentProcessManager
{
	@SuppressWarnings("unused")
	private static Logger log = Logger.getLogger( RivegaucheFulfilmentProcessManager.class.getName() );
	
	public static final RivegaucheFulfilmentProcessManager getInstance()
	{
		ExtensionManager em = JaloSession.getCurrentSession().getExtensionManager();
		return (RivegaucheFulfilmentProcessManager) em.getExtension(RivegaucheFulfilmentProcessConstants.EXTENSIONNAME);
	}
	
}
