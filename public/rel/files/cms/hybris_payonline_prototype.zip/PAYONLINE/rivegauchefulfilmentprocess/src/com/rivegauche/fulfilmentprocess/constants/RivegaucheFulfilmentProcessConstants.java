/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2013 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 * 
 *  
 */
package com.rivegauche.fulfilmentprocess.constants;

import de.hybris.platform.util.Config;

public final class RivegaucheFulfilmentProcessConstants extends GeneratedRivegaucheFulfilmentProcessConstants
{
	public static final String CONSIGNMENT_SUBPROCESS_END_EVENT_NAME = "ConsignmentSubprocessEnd";
	public static final String ORDER_PROCESS_NAME = "order-process";
	public static final String CONSIGNMENT_SUBPROCESS_NAME = "consignment-process";
	public static final String WAIT_FOR_WAREHOUSE = "WaitForWarehouse";
	public static final String CONSIGNMENT_PICKUP = "ConsignmentPickup";
	public static final String CONSIGNMENT_COUNTER = "CONSIGNMENT_COUNTER";
	public static final String PARENT_PROCESS = "PARENT_PROCESS";
	public static final String RG_CASHONDELIVERY_PAYMENT_MODE_CODE = "rg_cashondelivery.payment.mode.code";
    	public static final String RG_PAYONLINE_PAYMENT_MODE_CODE = "rg_payonline.payment.mode.code";

}
