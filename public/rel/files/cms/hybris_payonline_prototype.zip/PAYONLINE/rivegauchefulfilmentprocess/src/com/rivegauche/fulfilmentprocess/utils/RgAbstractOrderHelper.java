package com.rivegauche.fulfilmentprocess.utils;

import com.rivegauche.enums.OrderType;
import de.hybris.platform.core.model.order.AbstractOrderEntryModel;
import de.hybris.platform.core.model.order.AbstractOrderModel;
import org.apache.commons.collections.CollectionUtils;

public class RgAbstractOrderHelper {

    public static boolean hasOnlyPickUp(AbstractOrderModel order) {
        boolean hasPickUp = true;
        if (CollectionUtils.isNotEmpty(order.getEntries())) {
            for (AbstractOrderEntryModel entry : order.getEntries()) {
                if (!entry.getGiveAway() && entry.getDeliveryPointOfService() == null) {
                    hasPickUp = false;
                    break;
                }
            }
        }
        return hasPickUp;
    }

    public static boolean hasPickUp(AbstractOrderModel order) {
        boolean hasPickUp = false;
        if (CollectionUtils.isNotEmpty(order.getEntries())) {
            for (AbstractOrderEntryModel entry : order.getEntries()) {
                if (!entry.getGiveAway() && entry.getDeliveryPointOfService() != null) {
                    hasPickUp = true;
                    break;
                }
            }
        }
        return hasPickUp;
    }

    public static boolean hasDelivery(AbstractOrderModel order) {
        boolean hasDelivery = false;
        if (CollectionUtils.isNotEmpty(order.getEntries())) {
            for (AbstractOrderEntryModel entry : order.getEntries()) {
                if (!entry.getGiveAway() && entry.getDeliveryPointOfService() == null) {
                    hasDelivery = true;
                    break;
                }
            }
        }
        return hasDelivery;
    }

    public static OrderType getOrderType(AbstractOrderModel order) {
        OrderType orderType = OrderType.DELIVERY;

        if (hasDelivery(order) && hasPickUp(order)) {
            orderType = OrderType.PICKUP_AND_DELIVERY;
        } else if (hasOnlyPickUp(order)) {
            orderType = OrderType.PICKUP;
        }

        return orderType;
    }
}
