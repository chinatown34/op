package com.rivegauche.fulfilmentprocess.listeners;

import de.hybris.platform.basecommerce.model.site.BaseSiteModel;
import de.hybris.platform.commerceservices.enums.SiteChannel;
import de.hybris.platform.commerceservices.event.AbstractSiteEventListener;
import de.hybris.platform.core.model.order.OrderModel;
import de.hybris.platform.orderprocessing.events.AuthorizationFailedEvent;
import de.hybris.platform.orderprocessing.model.OrderProcessModel;
import de.hybris.platform.processengine.BusinessProcessService;
import de.hybris.platform.servicelayer.model.ModelService;
import de.hybris.platform.servicelayer.util.ServicesUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class AuthorizationFailedEventListener extends AbstractSiteEventListener<AuthorizationFailedEvent>
{

    private final static Logger LOG = LoggerFactory.getLogger(AuthorizationFailedEventListener.class);

    @Autowired
    private ModelService modelService;
    @Autowired
    private BusinessProcessService businessProcessService;

    @Override
    protected void onSiteEvent(AuthorizationFailedEvent authorizationFailedEvent) {
        final OrderModel orderModel = authorizationFailedEvent.getProcess().getOrder();
        LOG.info("Creating sendOrderPaymentAuthorizationFailedEmailProcess for order '{}'", orderModel.getCode());
        final OrderProcessModel orderProcessModel = (OrderProcessModel) businessProcessService.createProcess(
                "sendOrderPaymentAuthorizationFailedEmailProcess-" + orderModel.getCode() + "-" + System.currentTimeMillis(),
                "sendOrderPaymentAuthorizationFailedEmailProcess");
        orderProcessModel.setOrder(orderModel);
        modelService.save(orderProcessModel);
        LOG.info("Starting sendOrderPaymentAuthorizationFailedEmailProcess business process '{}' for order '{}'", orderProcessModel.getPk(), orderModel.getCode());
        businessProcessService.startProcess(orderProcessModel);
        LOG.info("Started sendOrderPaymentAuthorizationFailedEmailProcess business process '{}' for order '{}'", orderProcessModel.getCode(), orderModel.getCode());
    }

    @Override
    protected boolean shouldHandleEvent(AuthorizationFailedEvent rgOrderStatusChangedEvent) {
        final OrderModel order = rgOrderStatusChangedEvent.getProcess().getOrder();
        ServicesUtil.validateParameterNotNullStandardMessage("event.order", order);
        final BaseSiteModel site = order.getSite();
        ServicesUtil.validateParameterNotNullStandardMessage("event.order.site", site);
        return SiteChannel.B2C.equals(site.getChannel());
    }
}

