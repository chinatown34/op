/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2013 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 * 
 *  
 */
package com.rivegauche.fulfilmentprocess.actions.order;

import com.rivegauche.enums.OrderType;
import com.rivegauche.fulfilmentprocess.events.RgPickupOrderDetailsEvent;
import de.hybris.platform.core.model.order.AbstractOrderEntryModel;
import de.hybris.platform.core.model.order.OrderModel;
import de.hybris.platform.orderprocessing.events.OrderPlacedEvent;
import de.hybris.platform.orderprocessing.model.OrderProcessModel;
import de.hybris.platform.processengine.action.AbstractProceduralAction;
import de.hybris.platform.servicelayer.event.EventService;
import de.hybris.platform.servicelayer.event.events.AbstractEvent;
import de.hybris.platform.storelocator.model.PointOfServiceModel;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Required;

import java.util.HashSet;
import java.util.List;
import java.util.Set;


public class SendOrderPlacedNotificationAction extends AbstractProceduralAction<OrderProcessModel> {
    private static final Logger LOG = Logger.getLogger(SendOrderPlacedNotificationAction.class);

    private EventService eventService;

    @Override
    public void executeAction(final OrderProcessModel process) {
        OrderModel order = process.getOrder();
        if (order != null) {
            publishAndLogEventForOrder(new OrderPlacedEvent(process), order);
            sendEmailsForPickupOrders(order);
        }
        LOG.info("Process: " + process.getCode() + " in step " + getClass());
    }

    protected void sendEmailsForPickupOrders(OrderModel order) {
        if (isOrderForPickUp(order)) {
            Set<PointOfServiceModel> pointsOfService = new HashSet<>();

            List<AbstractOrderEntryModel> entries = order.getEntries();
            for (AbstractOrderEntryModel entry : entries) {
                pointsOfService.add(entry.getDeliveryPointOfService());
            }

            for (PointOfServiceModel pointOfService : pointsOfService) {
                publishAndLogEventForOrder(new RgPickupOrderDetailsEvent(order, pointOfService), order, pointOfService);
            }
        }
    }

    protected void publishAndLogEventForOrder(AbstractEvent event, OrderModel order) {
        publishAndLogEventForOrder(event, order, null);
    }

    protected void publishAndLogEventForOrder(AbstractEvent event, OrderModel order, PointOfServiceModel pointOfService) {
        getEventService().publishEvent(event);
        if (LOG.isDebugEnabled()) {
            StringBuilder msg = new StringBuilder("Publishing ").append(event.getClass().getName()).append(" for order code : ").append(order.getCode());
            if (pointOfService != null) {
                msg.append(" and point for point of service : ").append(pointOfService.getName());
            } else {
                msg.append(" and payment status : '").append(order.getPaymentStatus()).append("'");
            }
            LOG.debug(msg.toString());
        }
    }

    public boolean isOrderForPickUp(OrderModel order) {
        return OrderType.PICKUP.equals(order.getOrderType());
    }

    protected EventService getEventService() {
        return eventService;
    }

    @Required
    public void setEventService(final EventService eventService) {
        this.eventService = eventService;
    }
}
