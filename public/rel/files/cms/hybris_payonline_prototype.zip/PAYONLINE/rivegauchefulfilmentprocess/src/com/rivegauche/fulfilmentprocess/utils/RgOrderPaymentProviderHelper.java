package com.rivegauche.fulfilmentprocess.utils;


import com.rivegauche.model.RgPaymentInfoModel;
import com.rivegauche.model.RgPayonlinePaymentInfoModel;
import com.teamidea.integration.prototype.exception.PayonlinePrototypeException;
import com.teamidea.integration.prototype.payonline.client.PayonlineClient;
import com.teamidea.integration.prototype.payonline.model.PayonlineSearchResponse;
import de.hybris.platform.core.enums.PaymentStatus;
import de.hybris.platform.core.model.order.OrderModel;
import org.apache.log4j.Logger;

public class RgOrderPaymentProviderHelper {

    private static final Logger LOG = Logger.getLogger(RgOrderPaymentProviderHelper.class);

    private PayonlineClient payonlineClient;

    public void init() throws PayonlinePrototypeException {
        payonlineClient = new PayonlineClient();
    }

    public PaymentStatus getPaymentProviderOrderPaymentStatus(OrderModel order) {
        PaymentStatus status = null;
        RgPaymentInfoModel rgPaymentInfo = order.getRgPaymentInfo();
        if (RgPayonlinePaymentInfoModel._TYPECODE.equals(rgPaymentInfo.getItemtype())) {

            RgPayonlinePaymentInfoModel paymentInfoModel = (RgPayonlinePaymentInfoModel) rgPaymentInfo;
            status = getPayonlinePaymentStatus(order.getCode(), paymentInfoModel.getTransactionId());

        } 
        return status;
    }

    private PaymentStatus getPayonlinePaymentStatus(String orderCode, String orderPayonlineTransactionId) {
        PaymentStatus status = null;
        try {
            PayonlineSearchResponse payonlineSearchResponse = payonlineClient.search(orderCode, orderPayonlineTransactionId);
            if (payonlineSearchResponse != null) {
                String payonlineTransactionStatus = payonlineSearchResponse.getStatus();
                // FIX: Customer requirements: Orders in status PENDING or SETTLED are allowed to be sent to ERP
                if (PayonlineClient.TransactionStatus.Pending.toString().equals(payonlineTransactionStatus) 
                		|| PayonlineClient.TransactionStatus.Settled.toString().equals(payonlineTransactionStatus)) {
                    status = PaymentStatus.PAID;
                }
            }
        } catch (PayonlinePrototypeException e) {
            LOG.error("Error searching payonline transaction = " + orderPayonlineTransactionId + " for order = " + orderCode, e);
        }
        return status;
    }
}
