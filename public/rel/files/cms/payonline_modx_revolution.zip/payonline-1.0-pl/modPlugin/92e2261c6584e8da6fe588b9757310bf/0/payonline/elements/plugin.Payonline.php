<?php
if(isset($_GET['mode']) && 'payonline'==$_GET['mode']) {
    include(MODX_CORE_PATH . 'components/payonline/pol.php');
    $pol = new Pol($modx);
    $pol->response();
}