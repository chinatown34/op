﻿<?php
/* dependab1e@ya.ru 
** payment module for Modx Shopkeeper 3
*/

class Pol {
  private $conf;
  private $modx;
  function __construct($modx)
  {
    $this->modx = &$modx;
    $snippet = $this->modx->getObject('modSnippet',array('name'=>'Payonline'));
    $this->conf = $snippet->getProperties();
  }  

  function getForm()
  {
    $pls = $this->conf;
    if(!isset($_SESSION['shk_lastOrder'])) return;
    $o = $_SESSION['shk_lastOrder'];
    if(false!==stripos($o['currency'], '$') || false!==stripos($o['currency'], 'usd')) $o['currency'] = 'USD'; 
    elseif(false!==stripos($o['currency'], 'eur') || false!==stripos($o['currency'], '€')) $o['currency'] = 'EUR'; 
    else $o['currency'] = 'RUB';
    $o['price']	= str_replace(',', '.', number_format($o['price'], 2, '.', ''));
    $arr = array( 
      'MerchantId'=>$this->conf['merchantId'],
      'OrderId'=>$o['id'],
      'Amount'=>$o['price'],
      'Currency'=>$o['currency'],
      'OrderDescription'=>'Оплата заказа №' . $o['id'],
      'PrivateSecurityKey'=>$this->conf['secretKey'],
    );
    $str = '';
    foreach($arr as $key=>$val) $str.= $key . '=' . $val . '&';  
    $pls['md5'] = md5(substr($str, 0 ,-1));
    $pls = array_merge($arr, $pls);
  	$chunk = $this->get4nk('chunk');
    return $chunk->process($pls);

  }

  function response()
  {
		$z = &$_REQUEST;
    $this->modx->addPackage('shopkeeper3', MODX_CORE_PATH . 'components/shopkeeper3/model/');
    $order = $this->modx->getObject('shk_order', $z['OrderId']);
    if(!$order) die('Order ' .$z['OrderId']. ' not found.');
		$str = 'DateTime='.$z['DateTime'].'&TransactionID='.$z['TransactionID'].'&OrderId='.$z['OrderId'].'&Amount='.$z['Amount'].'&Currency='.$z['Currency'].'&PrivateSecurityKey='.$this->conf['secretKey']; 
		if(md5($str)==$z['SecurityKey']) 
		{	
      if(is_numeric($this->conf['orderStatus'])) {
        $order->set('status', $this->conf['orderStatus']);
        $this->modx->invokeEvent('OnSHKChangeStatus', array('order_id'=>$z['OrderId'], 'status'=>$this->conf['orderStatus']));
      }      
      $note = $order->get('note') . "\n Оплачено " .$z['DateTime']. ' через Payonline ' . $z['Provider'];
      $order->set('note', $note);
      $order->save();
		}

	}


  function get4nk($name)
  {
    $file = dirname(__FILE__) . '/' . $name . '.tpl';
    if (file_exists($file)) $content = file_get_contents($file);
  	if (!empty($content) && $content !== '0') $chunk_arr = array('name'=>$file,'snippet'=>$content);
  	$chunk = $this->modx->newObject('modChunk');
  	$chunk->fromArray($chunk_arr);
  	$chunk->setCacheable(false);
  	return $chunk;

  }

}