--------------------
Payonline
--------------------
Version: 1.0
Since: 15.08.2016
Author: Dependable (dependab1e@ya.ru)
--------------------
Payment module for Shopkeeper 3
--------------------
Установка:
1.Зайдите по адресу https://secure.payonlinesystem.com/merchant/sites/view/?id=74846&content=Settings
  Кликните на ссылку "Изменить".
  Режим безопасности:	Standart
  Callback Url для успешных транзакций: http://vash-site.xxx/?mode=payonline
  Включаем "Вызывать Callback для подтвержденных транзакций"
  Callback url encoding: utf-8
  Callback method: GET
  Нажимаем на "Сохранить изменения"
  Страницу не закрываем.

2.Кликаем на сниппет Payonline, закладка "Параметры".   
  Копируем из незакрытой страницы Merchant Id и "Private security key".
  Если нужно сменить статус после успешной оплаты - пишем порядковый номер статуса в orderStatus.
  Номер можно взять в настройках Shopkeeper /manageк/index.php?a=settings&namespace=shopkeeper3
   
3.На страницу, где должна быть кнопка "Оплатить" (обычно это страница "Спасибо, ваш заказ принят")
  вставьте запуск сниппета. [[!Payonline]] 

Можно принимать платежи.