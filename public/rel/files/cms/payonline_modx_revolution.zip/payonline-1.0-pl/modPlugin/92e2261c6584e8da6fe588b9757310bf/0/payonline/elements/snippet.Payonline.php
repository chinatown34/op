<?php
include(MODX_CORE_PATH . 'components/payonline/pol.php');
$pol = new Pol($modx);
return $pol->getForm();